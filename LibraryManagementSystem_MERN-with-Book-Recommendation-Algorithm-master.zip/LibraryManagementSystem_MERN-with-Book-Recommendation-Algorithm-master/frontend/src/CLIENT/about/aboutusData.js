export const about_data = [
  {
    id: 1,
    title: `Our Story`,
    description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua.`,
  },
  {
    id: 2,
    title: `Our Mission`,
    description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua.`,
  },
  {
    id: 3,
    title: `Our Team`,
    description: `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua.`,
  },
]
